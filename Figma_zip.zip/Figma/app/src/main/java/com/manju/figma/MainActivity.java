package com.manju.figma;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class MainActivity extends AppCompatActivity {

    Button mregbtn;
    TextView mtxtfullname, mtxtemail, mtxtpassword, mobno, mlogin;
    String name;
    String email ,mbno;
    String password;

    int moblno;

    database db;

    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    ImageView googlebtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mregbtn = findViewById(R.id.registerbtn);
        mtxtfullname = findViewById(R.id.fullname);
        mtxtemail = findViewById(R.id.email);
        mtxtpassword = findViewById(R.id.password);
        mobno = findViewById(R.id.mobno);

        mlogin = findViewById(R.id.login);

        //create database object
        db = new database(getApplicationContext(), "dbUsers", null, 1);

        mregbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (validateelements()) {

                    //insert data into users table
                    db.register(name, mbno, email, password);
                    Toast.makeText(getApplicationContext(), "Register sucessfully!", Toast.LENGTH_SHORT).show();
                    openloginPage();
                }

            }
        });

        mlogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                openloginPage();
            }
        });

        googlebtn = findViewById(R.id.imagegoogle);
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(this, gso);

        googlebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
    }

    void signIn(){
        Intent signInIntent = gsc.getSignInIntent();
        startActivityForResult(signInIntent, 1000);
    }

    public boolean validateelements()
    {
        name =mtxtfullname.getText().toString();
        email = mtxtemail.getText().toString();
        password = mtxtpassword.getText().toString();
        mbno=mobno.getText().toString();

        if(name.length()==0 || email.length()==0||password.length()==0|| mbno.length()==0)
            Toast.makeText(getApplicationContext(),"Please fill all details",Toast.LENGTH_SHORT).show();
        else
        {
            if(password.length()<8)
            {
                Toast.makeText(getApplicationContext(),"Password must be 8 digit !",Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }
        return false;
    }

    public void openloginPage()
    {
        Intent i = new Intent(this, login.class);
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1000)
        {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                task.getResult(ApiException.class);
                openMainActivity();
            } catch (ApiException e) {
                Toast.makeText(getApplicationContext(),"Something went wrong", Toast.LENGTH_SHORT).show();
            }
        }
    }
public void openMainActivity() {
    Intent i = new Intent(this, MainActivity.class);
    googlebtn.setVisibility(View.INVISIBLE);
    startActivity(i);
}
}