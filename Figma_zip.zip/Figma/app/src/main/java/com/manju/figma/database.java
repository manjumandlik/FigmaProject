package com.manju.figma;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class database extends SQLiteOpenHelper {

    public database(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String qry ="create table user(name text ,mno text, email text, password text)";
        db.execSQL(qry);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    // db.register(name,moblno,email,password);
    public void register(String name,String mno,String email,String password)
    {
        ContentValues cv = new ContentValues();

        cv.put("name",name);
        cv.put("mno",mno);
        cv.put("email",email);
        cv.put("password",password);

        SQLiteDatabase db = getWritableDatabase();
        db.insert("user",null,cv);
        db.close();
    }
    public int login(String emailnm, String password)
    {
        int result=0; Cursor c;
        String str[] = new String[2];
        str[0]= emailnm;
        str[1]= password;

        SQLiteDatabase db = getReadableDatabase();
        if(emailnm.contains("@")) {
             c = db.rawQuery("select * from user where email=? and password =?", str);
        }
        else
             c = db.rawQuery("select * from user where mno=? and password =?", str);

        if(c.moveToFirst())
        {
            result=1;
        }
        return result;
    }
}
