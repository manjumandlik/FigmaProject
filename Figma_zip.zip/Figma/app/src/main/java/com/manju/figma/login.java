package com.manju.figma;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class login extends AppCompatActivity {

    TextView memailormobileno, mpassword,mcreateacc;
    Button mbtnlgn;
    database db;

    String email;
    String passwrd;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        memailormobileno = findViewById(R.id.emailmoblg);
        mpassword =  findViewById(R.id.passwordlg);

        mcreateacc = findViewById(R.id.createaccount);
        mbtnlgn=  findViewById(R.id.loginbtn);

        db = new database(getApplicationContext(), "dbUsers", null, 1);
        mbtnlgn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validateelements()) {
                    if(db.login(email,passwrd)==1) {

                        Toast.makeText(getApplicationContext(),"Logged sucessfully!",Toast.LENGTH_SHORT).show();
                        openworkstationPage();
                    }
                    else
                        Toast.makeText(getApplicationContext(),"Invalid details!",Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(getApplicationContext(),"Please fill all details",Toast.LENGTH_SHORT).show();
            }
        });

        mcreateacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openloginPage();
            }
        });

    }

    public boolean validateelements()
    {
        email = memailormobileno.getText().toString();
        passwrd = mpassword.getText().toString();

        if(email.length()==0||passwrd.length()==0)
            return false;

        return true;

    }
    public void openworkstationPage()
    {
      Intent i = new Intent(this,bookworkstation.class);
       startActivity(i);
    }

    public void openloginPage()
    {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}