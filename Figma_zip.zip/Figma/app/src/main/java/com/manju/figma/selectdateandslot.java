package com.manju.figma;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.Toast;

import java.util.Calendar;

public class selectdateandslot extends AppCompatActivity {

    CalendarView calvw;
    Calendar cal;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectdateandslot);
        calvw = findViewById(R.id.calenderview);
        cal= Calendar.getInstance();

        calvw.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                Toast.makeText(getApplicationContext(),dayOfMonth+"/"+month+"/"+year, Toast.LENGTH_SHORT).show();
                openselecttimeActivity();
            }
        });
    }

    void openselecttimeActivity()
    {
        finish();
        Intent i = new Intent(this, timeactivity.class);
        startActivity(i);
    }
}